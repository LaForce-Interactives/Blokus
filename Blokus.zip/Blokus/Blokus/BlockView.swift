//
//  BlockView.swift
//  Blokus
//
//  Created by William Dong on 2017/3/8.
//  Copyright © 2017年 William Dong. All rights reserved.
//

import Foundation
import UIKit
import QuartzCore

class BlockView:UIView{

    var block:Block
    var delegate:Game?
    var isSelected:Bool
    
    init(frame f: CGRect,block blc:Block) {
        self.block=blc
        isSelected=false
        super.init(frame: f)
        self.backgroundColor=UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func draw(_ rect: CGRect){
        let path=UIBezierPath()
        let unit=Float(rect.width/6)
        
        for coord in block.points{
            let x=Float(rect.width)/2+(Float(coord.x)-Float(block.width)/2)*unit
            let y=Float(rect.height)/2+(Float(coord.y)-Float(block.height)/2)*unit
            
            let rect=CGRect(x:CGFloat(x), y:CGFloat(y), width:CGFloat(unit), height:CGFloat(unit))
            path.append(UIBezierPath(rect:rect))
        }
        
        var c=delegate!.colorForPlayer(id: block.owner.identifier)
        if isSelected{
            path.lineWidth=2
            c=c.withAlphaComponent(0.75)
        }
        c.setFill()
        UIColor.black.setStroke()
        path.fill()
        path.stroke()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //print("began")
        if delegate!.selectedView == nil && delegate!.currentPlayer == block.owner{
            delegate!.currentPlayer.blockplate!.isUserInteractionEnabled=false
            
            var r:CGRect
            if delegate!.players.count==2 {
                r=CGRect(x:0, y:0, width:240, height:240)
            }else{
                r=CGRect(x:0, y:0, width:180, height:180)
            }
            
            delegate!.selectedView=BlockView(frame:r, block:self.block)
            delegate!.selectedView!.isSelected=true
            delegate!.selectedView!.center=convert(CGPoint(x:90, y:90), to: delegate!.controller!.view)
            delegate!.selectedView!.delegate=delegate
            self.isHidden=true
            block.owner.selectedView=self
            delegate!.controller!.view.addSubview(delegate!.selectedView!)
            delegate!.controller!.view.sendSubview(toBack:delegate!.selectedView!)
            delegate!.controller!.view.sendSubview(toBack:delegate!.checkboard)
        }
        if self == delegate!.selectedView{
            delegate!.previousTouchPoint=touches.first!.location(in: delegate!.controller!.view)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if self==delegate!.selectedView {
            let p=touches.first!.location(in: delegate!.controller!.view)
            let dx=(p.x)-delegate!.previousTouchPoint.x
            let dy=(p.y)-delegate!.previousTouchPoint.y
            
            let newcenter=CGPoint(x:delegate!.selectedView!.center.x+dx, y:delegate!.selectedView!.center.y+dy)
            delegate!.selectedView!.center=newcenter
            delegate!.previousTouchPoint=p
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if (self==delegate!.selectedView){
            let p=center
            
            var ckbdrect:CGRect
            if delegate!.players.count==2 {
                ckbdrect=CGRect(x:104,y:232,width:560,height:560)
            }else{
                ckbdrect=CGRect(x:84,y:212,width:600,height:600)
            }
            
            if ckbdrect.contains(p) {
                block.owner.blockInCheckboard()
            }else{
                block.owner.blockOutCheckboard()
            }
        }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        touchesEnded(touches, with: event)
    }
    
}
