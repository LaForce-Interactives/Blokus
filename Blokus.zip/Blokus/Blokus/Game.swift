//
//  Game.swift
//  Blokus
//
//  Created by William Dong on 2017/3/16.
//  Copyright © 2017年 William Dong. All rights reserved.
//

import Foundation
import UIKit

class Game{
    
    var players:[Player]=[]
    var controller:ViewController?
    var checkboardStatus:[[Int]]=[]
    var checkboard:CheckboardView
    var currentPlayer:Player
    var selectedView:BlockView?
    var previousTouchPoint=CGPoint(x:0, y:0)
    
    init(playerCount: Int, controller:ViewController){
        self.controller=controller
        for i in 0...playerCount-1{
            let p=Player(id:i)
            players.append(p)
        }
        currentPlayer=players[0]
        
        switch playerCount {
        case 2:
            checkboardStatus=Array(repeating:Array(repeating:-1, count:14), count:14)
        case 4:
            checkboardStatus=Array(repeating:Array(repeating:-1, count:20), count:20)
        default:
            break
        }
        
        checkboard=CheckboardView(frame: CGRect(x:0,y:0,width:768,height:1024))
        checkboard.delegate=self
        self.controller!.view.addSubview(checkboard)
        
        for p in players{
            p.delegate=self
        }
        
        for p in players{
            p.RotateButton=UIButton.init(type: UIButtonType.system)
            p.FlipButton=UIButton.init(type: UIButtonType.roundedRect)
            p.OKButton=UIButton.init(type: UIButtonType.system)
            p.PASSButton=UIButton.init(type: UIButtonType.system)
        }
        switch playerCount {
        case 2:
            players[0].blockplate=UIScrollView(frame: CGRect(x:0,y:844,width:768,height:180))
            players[0].scoreLabel=UILabel(frame: CGRect(x:676,y:624,width:80,height:40))
            players[0].RotateButton!.frame = CGRect(x:676,y:664,width:80,height:40)
            players[0].FlipButton!.frame = CGRect(x:676,y:704,width:80,height:40)
            players[0].OKButton!.frame = CGRect(x:676,y:744,width:80,height:40)
            players[0].PASSButton!.frame = CGRect(x:676,y:784,width:80,height:40)

            players[1].blockplate=UIScrollView(frame: CGRect(x:0,y:0,width:768,height:180))
            players[1].scoreLabel=UILabel(frame: CGRect(x:12,y:360,width:80,height:40))
            players[1].scoreLabel!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[1].RotateButton!.frame = CGRect(x:12,y:320,width:80,height:40)
            players[1].RotateButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[1].FlipButton!.frame = CGRect(x:12,y:280,width:80,height:40)
            players[1].FlipButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[1].OKButton!.frame = CGRect(x:12,y:240,width:80,height:40)
            players[1].OKButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[1].PASSButton!.frame = CGRect(x:12,y:200,width:80,height:40)
            players[1].PASSButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
        case 4:
            players[0].blockplate=UIScrollView(frame: CGRect(x:0,y:844,width:384,height:180))
            players[0].scoreLabel=UILabel(frame: CGRect(x:2,y:624,width:80,height:40))
            players[0].RotateButton!.frame = CGRect(x:2,y:664,width:80,height:40)
            players[0].FlipButton!.frame = CGRect(x:2,y:704,width:80,height:40)
            players[0].OKButton!.frame = CGRect(x:2,y:744,width:80,height:40)
            players[0].PASSButton!.frame = CGRect(x:2,y:784,width:80,height:40)
            
            players[1].blockplate=UIScrollView(frame: CGRect(x:384,y:844,width:384,height:180))
            players[1].scoreLabel=UILabel(frame: CGRect(x:686,y:624,width:80,height:40))
            players[1].RotateButton!.frame = CGRect(x:686,y:664,width:80,height:40)
            players[1].FlipButton!.frame = CGRect(x:686,y:704,width:80,height:40)
            players[1].OKButton!.frame = CGRect(x:686,y:744,width:80,height:40)
            players[1].PASSButton!.frame = CGRect(x:686,y:784,width:80,height:40)
            
            players[2].blockplate=UIScrollView(frame: CGRect(x:384,y:0,width:384,height:180))
            players[2].scoreLabel=UILabel(frame: CGRect(x:686,y:360,width:80,height:40))
            players[2].scoreLabel!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[2].RotateButton!.frame = CGRect(x:686,y:320,width:80,height:40)
            players[2].RotateButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[2].FlipButton!.frame = CGRect(x:686,y:280,width:80,height:40)
            players[2].FlipButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[2].OKButton!.frame = CGRect(x:686,y:240,width:80,height:40)
            players[2].OKButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[2].PASSButton!.frame = CGRect(x:686,y:200,width:80,height:40)
            players[2].PASSButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            
            players[3].blockplate=UIScrollView(frame: CGRect(x:0,y:0,width:384,height:180))
            players[3].scoreLabel=UILabel(frame: CGRect(x:2,y:360,width:80,height:40))
            players[3].scoreLabel!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[3].RotateButton!.frame = CGRect(x:2,y:320,width:80,height:40)
            players[3].RotateButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[3].FlipButton!.frame = CGRect(x:2,y:280,width:80,height:40)
            players[3].FlipButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[3].OKButton!.frame = CGRect(x:2,y:240,width:80,height:40)
            players[3].OKButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            players[3].PASSButton!.frame = CGRect(x:2,y:200,width:80,height:40)
            players[3].PASSButton!.transform=CGAffineTransform.init(rotationAngle: CGFloat(M_PI))
            
        default:
            break
        }
        
        for p in players {
            p.configureViews()
        }
    }
    
    func colorForPlayer(id:Int)->UIColor{
        switch id {
        case 0:
            return UIColor.red
        case 1:
            return UIColor.green
        case 2:
            return UIColor.yellow
        case 3:
            return UIColor.blue
        default:
            break
        }
        return UIColor.white
    }
    
    func turnDidEnd(id:Int)->Void{
        var i=(id+1)%players.count
        while (players[i].hasPassed) && (i != id){
            i=(i+1)%players.count
        }
        if (i == id) && (players[i].hasPassed) {
            controller!.endGame()
        }else{
            players[i].beginTurn()
        }
    }
    
    func startPointForPlayer(id:Int)->coord{
        if players.count==2 {
            switch id {
            case 0:
                return coord(x:4, y:9)
            case 1:
                return coord(x:9, y:4)
            default:
                break
            }
        }else{
            switch id {
            case 0:
                return coord(x:0, y:19)
            case 1:
                return coord(x:19, y:19)
            case 2:
                return coord(x:19, y:0)
            case 3:
                return coord(x:0, y:0)
                
            default:
                break
            }
            
        }
        return coord(x:-1, y:-1)
    }
    
    func isValidMove(points:Array<coord>) -> Bool {
        let cbmax=checkboardStatus.count-1
        for p in points{
            if p.x<0 || p.x>cbmax || p.y<0 || p.y>cbmax {
                return false
            }
        }
        
        for p in points {
            if checkboardStatus[p.x][p.y] != -1 {
                return false
            }
        }
        
        if currentPlayer.blocks.count==21 {
            let sp=startPointForPlayer(id: currentPlayer.identifier)
            for p in points{
                if p.x==sp.x && p.y==sp.y {
                    return true
                }
            }
            return false
        }
        
        let a=currentPlayer.identifier
        
        for p in points {
            if p.x>0 {
                if checkboardStatus[p.x-1][p.y] == a {
                    return false
                }
            }
            
            if p.x<cbmax {
                if checkboardStatus[p.x+1][p.y] == a {
                    return false
                }
            }
            
            if p.y>0 {
                if checkboardStatus[p.x][p.y-1] == a {
                    return false
                }
            }
            
            if p.y<cbmax {
                if checkboardStatus[p.x][p.y+1] == a {
                    return false
                }
            }
        }
        
        for p in points{
            if p.x>0 && p.y>0{
                if checkboardStatus[p.x-1][p.y-1] == a{
                    return true
                }
            }
            
            if p.x<cbmax && p.y>0{
                if checkboardStatus[p.x+1][p.y-1] == a{
                    return true
                }
            }
            
            if p.x>0 && p.y<cbmax{
                if checkboardStatus[p.x-1][p.y+1] == a{
                    return true
                }
            }
            
            if p.x<cbmax && p.y<cbmax{
                if checkboardStatus[p.x+1][p.y+1] == a{
                    return true
                }
            }
        }
        
        return false
    }
}
