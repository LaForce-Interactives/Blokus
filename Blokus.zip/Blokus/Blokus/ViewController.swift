//
//  ViewController.swift
//  Blokus
//
//  Created by William Dong on 2017/3/8.
//  Copyright © 2017年 William Dong. All rights reserved.
//

import UIKit
import QuartzCore
import CoreGraphics

class ViewController: UIViewController {
    
    var game:Game?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        newGame(sender: nil)
    }
    
    func endGame()->Void{
        var mes:String=""
        var names=["RED","GREEN","YELLOW","BLUE"]
        for i in 0...game!.players.count-1{
            mes=mes+names[i]+": "+String(game!.players[i].currentScore())
            if i<game!.players.count-1 {
                mes=mes+"\n"
            }
        }
        let alert=UIAlertController(title:"Good Game!", message: mes, preferredStyle: UIAlertControllerStyle.alert)
        let ac=UIAlertAction(title: "New Game", style: UIAlertActionStyle.default, handler: newGame)
        alert.addAction(ac)
        present(alert, animated: true, completion: nil)
    }
    
    func newGame(sender:UIAlertAction?)->Void {
        let alert=UIAlertController(title:"New Game", message: "Choose Mode", preferredStyle: UIAlertControllerStyle.alert)
        let ac1=UIAlertAction(title: "2 Players", style: UIAlertActionStyle.default, handler: begin2Game)
        let ac2=UIAlertAction(title: "4 Players", style: UIAlertActionStyle.default, handler: begin4Game)
        alert.addAction(ac1)
        alert.addAction(ac2)
        present(alert, animated: true, completion: nil)
    }
    
    func begin2Game(sender:UIAlertAction)->Void{
        for v in view.subviews {
            v.removeFromSuperview()
        }
        game=Game(playerCount: 2, controller:self)
        game!.controller=self
        game!.players[0].beginTurn()
    }
    
    func begin4Game(sender:UIAlertAction)->Void{
        for v in view.subviews {
            v.removeFromSuperview()
        }
        game=Game(playerCount: 4, controller:self)
        game!.controller=self
        game!.players[0].beginTurn()
    }
    
    override var prefersStatusBarHidden: Bool{
        return true
    }
}
