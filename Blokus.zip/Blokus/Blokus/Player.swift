//
//  Player.swift
//  Blokus
//
//  Created by William Dong on 2017/3/9.
//  Copyright © 2017年 William Dong. All rights reserved.
//

import Foundation
import UIKit

class Player:NSObject{
    
    var identifier:Int
    var blocks:[Block]
    var blockplate:UIScrollView?
    var RotateButton,FlipButton,OKButton,PASSButton:UIButton?
    var scoreLabel:UILabel?
    var delegate:Game?
    var hasPassed:Bool
    var selectedView:BlockView?

    init(id:Int){
        identifier=id
        blocks=[]
        hasPassed=false
        super.init()
        for i in 1...21{
            blocks.append(Block(id:i, owner:self))
        }
    }
    
    func currentScore()->Int{
        var s=89
        for blc in blocks{
            s-=blc.pointCount()
        }
        return s
    }
    
    func configureViews()->Void{
        RotateButton!.setTitle("Rotate", for: UIControlState.normal)
        FlipButton!.setTitle("Flip", for: UIControlState.normal)
        OKButton!.setTitle("OK", for: UIControlState.normal)
        PASSButton!.setTitle("PASS", for: UIControlState.normal)
        scoreLabel!.text=String(currentScore())
        
        for button in [RotateButton,FlipButton,OKButton,PASSButton]{
            button!.titleLabel!.font=UIFont.systemFont(ofSize: 25)
            button!.titleLabel!.textAlignment=NSTextAlignment.center
            button!.isEnabled=false
            delegate!.controller!.view.addSubview(button!)
        }
        
        scoreLabel!.font=UIFont.systemFont(ofSize: 25)
        scoreLabel!.textAlignment=NSTextAlignment.center
        delegate!.controller!.view.addSubview(scoreLabel!)
        
        drawPlate()
        blockplate!.backgroundColor=delegate!.colorForPlayer(id: identifier).withAlphaComponent(0.1)
        blockplate!.showsHorizontalScrollIndicator=false
        delegate!.controller!.view.addSubview(blockplate!)
        
        RotateButton!.addTarget(self, action: #selector(Player.Rotate), for: UIControlEvents.touchUpInside)
        FlipButton!.addTarget(self, action: #selector(Player.Flip), for: UIControlEvents.touchUpInside)
        OKButton!.addTarget(self, action: #selector(Player.OK), for: UIControlEvents.touchUpInside)
        PASSButton!.addTarget(self, action: #selector(Player.PASS), for: UIControlEvents.touchUpInside)
    }
    
    func drawPlate()->Void{
        for v in blockplate!.subviews{
            v.removeFromSuperview()
        }
        
        blockplate!.contentSize=CGSize(width:blocks.count*180, height:180)
        var i=0
        for blc in blocks{
            let rect=CGRect(x:i*180,y:0,width:180,height:180)
            let v=BlockView(frame: rect, block:blc)
            v.delegate=self.delegate
            blockplate!.addSubview(v)
            i += 1
        }
        blockplate!.setNeedsDisplay()
    }
    
    func beginTurn()->Void{
        delegate!.currentPlayer=self
        PASSButton!.isEnabled=true
    }
    
    func blockInCheckboard()->Void{
        let blkv=delegate!.selectedView!
        let a,b:CGFloat
        var unit,x0,y0:CGFloat
        if delegate!.players.count==2 {
            unit=40
            x0=104
            y0=232
        }else{
            unit=30
            x0=84
            y0=212
        }
        
        if blkv.block.width%2==0 {
            a=CGFloat(Int((blkv.center.x-x0)/unit+0.5))*unit+x0
        }else{
            a=CGFloat(Int((blkv.center.x-x0)/unit))*unit+x0+0.5*unit
        }
        
        if blkv.block.height%2==0 {
            b=CGFloat(Int((blkv.center.y-y0)/unit+0.5))*unit+y0
        }else{
            b=CGFloat(Int((blkv.center.y-y0)/unit))*unit+y0+0.5*unit
        }
        blkv.center=CGPoint(x:a, y:b)
        
        RotateButton!.isEnabled=true
        FlipButton!.isEnabled=true
        
        if delegate!.isValidMove(points: selectedPoints()) {
            OKButton!.isEnabled=true
        }else{
            OKButton!.isEnabled=false
        }
    }
    
    func selectedPoints()->[coord]{
        let p=delegate!.selectedView!.center
        let a=p.x
        let b=p.y
        let c,d:Int
        
        var unit,x0,y0:CGFloat
        if delegate!.players.count==2 {
            unit=40
            x0=104
            y0=232
        }else{
            unit=30
            x0=84
            y0=212
        }
        
        if selectedView!.block.width%2==0 {
            c=Int((a-x0)/unit+0.5)-selectedView!.block.width/2
        }else{
            c=Int((a-x0)/unit)-selectedView!.block.width/2
        }
        
        if selectedView!.block.height%2==0 {
            d=Int((b-y0)/unit+0.5)-selectedView!.block.height/2
        }else{
            d=Int((b-y0)/unit)-selectedView!.block.height/2
        }
        
        var pts:[coord]=[]
        for p in selectedView!.block.points {
            pts.append(coord(x:p.x+c, y:p.y+d))
        }
        return pts
    }
    
    func blockOutCheckboard()->Void{
        selectedView!.isHidden=false
        selectedView=nil
        blockplate!.isUserInteractionEnabled=true
        OKButton!.isEnabled=false
        RotateButton!.isEnabled=false
        FlipButton!.isEnabled=false
        
        delegate!.selectedView!.removeFromSuperview()
        delegate!.selectedView=nil
    }
    
    func Rotate()->Void{
        selectedView!.block.rotate()
        selectedView!.setNeedsDisplay()
        delegate!.selectedView!.setNeedsDisplay()
        if (selectedView!.block.width%2)^(selectedView!.block.height%2)==0 {
            if delegate!.isValidMove(points: selectedPoints()) {
                OKButton!.isEnabled=true
            }else{
                OKButton!.isEnabled=false
            }
        }else{
            OKButton!.isEnabled=false
        }
    }
    
    func Flip()->Void{
        selectedView!.block.flip()
        selectedView!.setNeedsDisplay()
        delegate!.selectedView!.setNeedsDisplay()
        if delegate!.isValidMove(points: selectedPoints()) {
            OKButton!.isEnabled=true
        }else{
            OKButton!.isEnabled=false
        }
    }
    
    func OK()->Void{
        if delegate!.isValidMove(points: selectedPoints())==false{
            return
        }
        for p in selectedPoints() {
            delegate!.checkboardStatus[p.x][p.y]=identifier
        }
        delegate!.checkboard.setNeedsDisplay()
        
        delegate!.selectedView!.removeFromSuperview()
        delegate!.selectedView=nil
        
        var p:Int=0
        for i in 0...blocks.count-1 {
            if blocks[i].identifier==selectedView!.block.identifier {
                p=i
            }
        }
        blocks.remove(at: p)
        
        drawPlate()
        blockplate!.isUserInteractionEnabled=true
        scoreLabel!.text=String(currentScore())
        
        selectedView=nil
        endTurn()
    }
    
    func PASS()->Void{
        selectedView?.isHidden=false
        selectedView=nil
        
        delegate!.selectedView?.removeFromSuperview()
        delegate!.selectedView=nil
        
        blockplate!.isUserInteractionEnabled=true
        
        hasPassed=true
        endTurn()
    }
    
    func endTurn()->Void{
        RotateButton!.isEnabled=false
        FlipButton!.isEnabled=false
        OKButton!.isEnabled=false
        PASSButton!.isEnabled=false
        
        delegate!.turnDidEnd(id:identifier)
    }
}
