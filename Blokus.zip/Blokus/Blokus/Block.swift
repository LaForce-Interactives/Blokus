//
//  Block.swift
//  Blokus
//
//  Created by William Dong on 2017/3/8.
//  Copyright © 2017年 William Dong. All rights reserved.
//

import Foundation

struct coord{
    var x:Int
    var y:Int
}

class Block{
    
    var identifier,width,height:Int
    var points:[coord]
    var owner:Player
    
    init(id:Int, owner:Player){
        identifier=id
        width=0
        height=0
        points=[coord]()
        self.owner=owner;
        //设置每块拼图的编号 先统一为丁字形
        switch identifier {
        case 1:
            width=1
            height=1
            points=[coord(x: 1,y: 1)]
            
        case 2:
            width=2
            height=1
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1)]

        case 3:
            width=3
            height=1
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1)]

        case 4:
            width=2
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 2,y: 2)]

        case 5:
            width=4
            height=1
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 4,y: 1)]

        case 6:
            width=3
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 3,y: 2)]
            
        case 7:
            width=3
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 2,y: 2)]
            
        case 8:
            width=3
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 2,y: 2),coord(x: 3,y: 2)]
            
        case 9:
            width=2
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 1,y: 2),coord(x: 2,y: 2)]
            
        case 10:
            width=5
            height=1
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 4,y: 1),coord(x: 5,y: 1)]
            
        case 11:
            width=4
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 4,y: 1),coord(x: 4,y: 2)]
            
        case 12:
            width=4
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 4,y: 1),coord(x: 3,y: 2)]
            
        case 13:
            width=3
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 3,y: 2),coord(x: 2,y: 2)]
            
        case 14:
            width=3
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 3,y: 2),coord(x: 1,y: 2)]
            
        case 15:
            width=3
            height=3
            points=[coord(x: 1,y: 2),coord(x: 2,y: 2),coord(x: 3,y: 2),coord(x: 1,y: 1),coord(x: 3,y: 3)]
            
        case 16:
            width=3
            height=3
            points=[coord(x: 1,y: 2),coord(x: 2,y: 2),coord(x: 3,y: 2),coord(x: 3,y: 1),coord(x: 2,y: 3)]
            
        case 17:
            width=3
            height=3
            points=[coord(x: 1,y: 2),coord(x: 2,y: 2),coord(x: 3,y: 2),coord(x: 3,y: 1),coord(x: 3,y: 3)]
            
        case 18:
            width=4
            height=2
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 3,y: 2),coord(x: 4,y: 2)]
            
        case 19:
            width=3
            height=3
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 2,y: 2),coord(x: 3,y: 2),coord(x: 3,y: 3)]
            
        case 20:
            width=3
            height=3
            points=[coord(x: 1,y: 2),coord(x: 2,y: 2),coord(x: 3,y: 2),coord(x: 2,y: 1),coord(x: 2,y: 3)]
            
        case 21:
            width=3
            height=3
            points=[coord(x: 1,y: 1),coord(x: 2,y: 1),coord(x: 3,y: 1),coord(x: 3,y: 2),coord(x: 3,y: 3)]
            
        default:
            break
        }
        
        var pts:[coord]=[]
        for p in points {
            pts.append(coord(x:p.x-1,y:p.y-1))
        }
        points=pts
    }
    
    func pointCount()->Int{
        return points.count
    }
    
    func rotate()-> Void{
        var pts:[coord]=[]
        for p in points {
            pts.append(coord(x:height-1-p.y, y:p.x))
        }
        points=pts
        
        let tmp=width
        width=height
        height=tmp
    }
    
    func flip()->Void{
        var pts:[coord]=[]
        for p in points {
            pts.append(coord(x:width-1-p.x, y:p.y))
        }
        points=pts
    }
}
