//
//  CheckboardView.swift
//  Blokus
//
//  Created by William Dong on 2017/3/9.
//  Copyright © 2017年 William Dong. All rights reserved.
//

import Foundation
import UIKit

class CheckboardView:UIView{
    
    var delegate:Game?
    
    override init(frame:CGRect){
        super.init(frame: frame)
        self.backgroundColor=UIColor.white
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder);
        //fatalError("init(coder:) has not been implemented")
    }
    
    override func draw(_ rect: CGRect){
        UIColor.black.setStroke()
        var unit:Float
        var size:Int
        if delegate!.players.count==2 {
            unit=40
            size=14
        }else{
            unit=30
            size=20
        }
        
        for i in 0...size-1{
            for j in 0...size-1{
                let path=UIBezierPath()
                let x=Float(i)*unit+(Float(rect.width)-unit*Float(size))/2
                let y=Float(j)*unit+(Float(rect.height)-unit*Float(size))/2
                let r=CGRect(x:CGFloat(x), y:CGFloat(y), width:CGFloat(unit), height:CGFloat(unit))
                path.append(UIBezierPath(rect:r))
                delegate!.colorForPlayer(id: delegate!.checkboardStatus[i][j]).setFill()
                path.fill()
                path.stroke()
            }
        }
        
        for plr in delegate!.players {
            let id=plr.identifier
            let p=delegate!.startPointForPlayer(id: id)
            if delegate!.checkboardStatus[p.x][p.y] == -1 {
                let path=UIBezierPath()
                let x=Float(p.x)*unit+(Float(rect.width)-unit*Float(size))/2+Float(unit/2)
                let y=Float(p.y)*unit+(Float(rect.height)-unit*Float(size))/2+Float(unit/2)
                let PI:CGFloat=3.1415926
                path.addArc(withCenter: CGPoint(x: CGFloat(x), y: CGFloat(y)), radius: CGFloat(unit/4), startAngle: 0.0, endAngle:2*PI, clockwise: true)
                delegate!.colorForPlayer(id: id).setFill()
                path.fill()
            }
        }
    }
}
